package com.svv.test;

import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.function.Function;

public class OrderStart {
	
	private static int serialNo = 0;
	
	public static void main(String[] args) {
		
		startOrder("V400123");
		startOrder("V400223");
		startOrder("V400323");
	}

	private static void startOrder(String variant) {
		
		ExecutorService exeService = Executors.newFixedThreadPool(10);
		
		CompletableFuture.supplyAsync(()->variant,exeService)
		.thenApplyAsync(new OrderStart().fetchOrderFunction,exeService)
		.thenApplyAsync(new OrderStart().generateSerialNumber,exeService)
		.thenAcceptAsync(new OrderStart().generateBuildSheet,exeService);

	}
	
	Function<String,Order> fetchOrderFunction = (variant)->
	{
		String orderNo = variant.substring(1,6);
		Order order = new Order();
		order.setOrderNo(orderNo);
		order.setVariant(variant);
		System.out.println("Order fetched "+ orderNo);
		return order;
	};
	
	Function<Order,Order> generateSerialNumber = (order)->
	{
		serialNo++;
		System.out.println("Serial no generated "+ serialNo);
		order.setVin(Integer.toString(serialNo));
		return order;
	};
	
	Consumer<Order> generateBuildSheet = (order) ->
	{
		System.out.println("Buildsheet generated ");
		CompletableFuture.supplyAsync(()->order)
		.thenAccept(new OrderStart().sendMail);
	};

	
	Consumer<Order> sendMail = (order) ->
	{
		System.out.println("mail send for the serial number " + order.getVin());
	};

}

